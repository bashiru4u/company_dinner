document.addEventListener('DOMContentLoaded', () => {
  // JavaScript removed for voting; voting is now server-side
  // You can retain any other JS behavior here if needed
});
